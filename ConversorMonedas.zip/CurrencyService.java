
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class CurrencyService {

    public static double obtenerTasa(String monedaOrigen, String monedaDestino) throws Exception {
        String urlStr = "https://api.exchangerate.host/latest?base=" + monedaOrigen;
        URL url = new URL(urlStr);

        HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
        conexion.setRequestMethod("GET");

        BufferedReader in = new BufferedReader(
                new InputStreamReader(conexion.getInputStream())
        );

        String inputLine;
        StringBuilder respuesta = new StringBuilder();

        while ((inputLine = in.readLine()) != null) {
            respuesta.append(inputLine);
        }
        in.close();

        JSONObject json = new JSONObject(respuesta.toString());
        return json.getJSONObject("rates").getDouble(monedaDestino);
    }
}
