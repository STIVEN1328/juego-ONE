
import javax.swing.*;

public class ConversorUI extends JFrame {

    private JTextField txtMonto;
    private JComboBox<String> comboOrigen, comboDestino;
    private JLabel lblResultado;

    public ConversorUI() {
        setTitle("Conversor de Monedas");
        setSize(400, 300);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel lblMonto = new JLabel("Monto:");
        lblMonto.setBounds(30, 30, 100, 25);
        add(lblMonto);

        txtMonto = new JTextField();
        txtMonto.setBounds(140, 30, 200, 25);
        add(txtMonto);

        JLabel lblOrigen = new JLabel("Moneda origen:");
        lblOrigen.setBounds(30, 70, 120, 25);
        add(lblOrigen);

        comboOrigen = new JComboBox<>(new String[]{"USD", "COP", "EUR", "MXN", "BRL"});
        comboOrigen.setBounds(140, 70, 200, 25);
        add(comboOrigen);

        JLabel lblDestino = new JLabel("Moneda destino:");
        lblDestino.setBounds(30, 110, 120, 25);
        add(lblDestino);

        comboDestino = new JComboBox<>(new String[]{"USD", "COP", "EUR", "MXN", "BRL"});
        comboDestino.setBounds(140, 110, 200, 25);
        add(comboDestino);

        JButton btnConvertir = new JButton("Convertir");
        btnConvertir.setBounds(140, 150, 120, 30);
        add(btnConvertir);

        lblResultado = new JLabel("Resultado: ");
        lblResultado.setBounds(30, 200, 300, 25);
        add(lblResultado);

        btnConvertir.addActionListener(e -> convertir());

        setVisible(true);
    }

    private void convertir() {
        try {
            double monto = Double.parseDouble(txtMonto.getText());
            String origen = comboOrigen.getSelectedItem().toString();
            String destino = comboDestino.getSelectedItem().toString();

            double tasa = CurrencyService.obtenerTasa(origen, destino);
            double resultado = monto * tasa;

            lblResultado.setText("Resultado: " + String.format("%.2f", resultado));

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese un monto válido");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al obtener la tasa de cambio");
        }
    }
}
