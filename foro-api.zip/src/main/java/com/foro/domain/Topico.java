package com.foro.domain;

import jakarta.persistence.*;

@Entity
public class Topico {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String titulo;
    private String mensaje;
    private String autor;

    public Topico() {}

    public Topico(String titulo, String mensaje, String autor) {
        this.titulo = titulo;
        this.mensaje = mensaje;
        this.autor = autor;
    }

    public Long getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getMensaje() { return mensaje; }
    public String getAutor() { return autor; }
}
