package com.foro.service;

import com.foro.domain.Topico;
import com.foro.repository.TopicoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TopicoService {

    private final TopicoRepository repository;

    public TopicoService(TopicoRepository repository) {
        this.repository = repository;
    }

    public List<Topico> listar() {
        return repository.findAll();
    }

    public Topico crear(Topico topico) {
        return repository.save(topico);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}
